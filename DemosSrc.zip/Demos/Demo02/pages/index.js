import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import styles from "../styles/MarkdownEditor.module.css";

function MarkdownEditor() {
    const [markdownText, setMarkdownText] = useState("ここにマークダウンを入力してください");

    const handleMarkdownChange = (event) => {
        setMarkdownText(event.target.value);
    };

    return (
        <div className={styles["markdown-editor"]}>
          <textarea className={styles["markdown-editor__textarea"]} value={markdownText} onChange={handleMarkdownChange} />
          <ReactMarkdown className={styles["markdown-editor__preview"]}>{markdownText}</ReactMarkdown>
        </div>
      );
}

export default MarkdownEditor;